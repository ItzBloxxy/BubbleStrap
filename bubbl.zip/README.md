<div align="center">
  <img 
    src="https://github.com/user-attachments/assets/ab9def97-3cdf-4739-936d-6672e2d4fc9c" 
    width="1640" 
    height="664" 
  />
</div>

> [!CAUTION]
> The only official places to download BubbleStrap is this GitHub repository. (for now)

BubbleStrap is a fast and lightweight bootstrapper for Roblox that aims to provide additional features to improve your experience.
- **BubbleStrap only supports Windows 10 and above.**
- **We do not have any plans to port it to any other operating systems.**

## Requires [NET 9.0 Runtime](https://dotnet.microsoft.com/en-us/download/dotnet/thank-you/sdk-9.0.308-windows-x64-installer)

Found any bugs or issues?
👉 [Submit an issue](https://github.com/ItzBloxxy/BubbleStrap/issues/new/choose)

Download the latest release [here][repo-latest]! 🔥

## Features
- Detailed player logs
- Detailed server information (Thanks to [RoValra](https://www.rovalra.com/))
- Studio Support
- FFlag editor
- Framerate cap unlocking
- Global Settings page
- Custom BubbleStrap game invite links
- Cache cleaner
- Channel changer
- Perfomance customization
- Much more (It just has been worked on)

[repo-latest]:   https://github.com/ItzBloxxy/BubbleStrap/releases/latest

## FAQ:
- **Is Bloxshade supported?** *No*, Bloxshade is generally no longer supported or functional due to recent, stricter security updates from Roblox that block the methods shaders like Bloxshade and NVIDIA Ansel rely on for injection, making them incompatible with new Roblox versions and risking moderation. While there were recent updates adding Bloxshade support, these changes have effectively broken the core functionality for most users. 

- **Will you get banend for this?** *No*, it does not violate the Roblox TOS.
