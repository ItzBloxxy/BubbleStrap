﻿namespace Wpf.Ui.Controls;

internal class MaximizeButton : System.Windows.Controls.Button
{
}
