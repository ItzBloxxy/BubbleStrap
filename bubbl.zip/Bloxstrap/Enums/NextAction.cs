﻿namespace Bloxstrap.Enums
{
    public enum NextAction
    {
        Terminate,
        LaunchSettings,
        LaunchRoblox,
        LaunchRobloxStudio
    }
}
