﻿namespace Bloxstrap.Enums
{
    public enum CookieState
    {
        Success,
        NotAllowed,
        NotFound,
        Invalid,
        Failed,
        Unknown
    }
}
