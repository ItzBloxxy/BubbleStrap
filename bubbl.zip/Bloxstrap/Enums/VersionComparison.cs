﻿namespace Bloxstrap.Enums
{
    enum VersionComparison
    {
        LessThan = -1,
        Equal = 0,
        GreaterThan = 1
    }
}
