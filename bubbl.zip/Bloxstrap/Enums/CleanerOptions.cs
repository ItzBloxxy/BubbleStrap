﻿namespace Bloxstrap.Enums
{
    public enum CleanerOptions
    {
        Never,
        OneDay,
        OneWeek,
        OneMonth,
        TwoMonths
    }
}