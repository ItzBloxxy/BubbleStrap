﻿namespace Bloxstrap.UI.Elements.About.Pages
{
    /// <summary>
    /// Interaction logic for LicensesPage.xaml
    /// </summary>
    public partial class LicensesPage
    {
        public LicensesPage()
        {
            InitializeComponent();
        }
    }
}
