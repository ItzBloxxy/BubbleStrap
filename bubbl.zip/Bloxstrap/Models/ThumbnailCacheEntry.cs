﻿namespace Bloxstrap.Models
{
    internal class ThumbnailCacheEntry
    {
        public ulong Id { get; set; }
        public string Url { get; set; } = string.Empty;
    }
}
