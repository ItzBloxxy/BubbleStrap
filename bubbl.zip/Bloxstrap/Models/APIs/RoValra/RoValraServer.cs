﻿namespace Bloxstrap.Models.APIs.RoValra
{
    public class RoValraServer
    {
        [JsonPropertyName("first_seen")]
        public DateTime? FirstSeen { get; set; }
    }
}
